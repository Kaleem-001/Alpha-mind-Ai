# Backend contract

Recommended endpoints:
POST /auth/session
POST /chat
POST /vision
POST /image/generate
POST /video/generate
GET /chats
POST /chats
DELETE /chats/:id
GET /admin/users
PATCH /admin/users/:id/status
GET /admin/usage
GET /health

Use server-side secrets only.
Recommended database:
users/profiles, chats, messages, usage_events, app_settings.
Enforce per-user access and admin role in the backend/database.
