create table profiles (
 id uuid primary key,
 email text,
 role text not null default 'user',
 active boolean not null default true,
 created_at timestamptz default now()
);

create table chats (
 id uuid primary key,
 user_id uuid not null,
 title text,
 created_at timestamptz default now()
);

create table messages (
 id uuid primary key,
 chat_id uuid not null,
 role text not null,
 content text not null,
 created_at timestamptz default now()
);

create table usage_events (
 id uuid primary key,
 user_id uuid not null,
 event_type text not null,
 units bigint not null default 1,
 created_at timestamptz default now()
);

/*
Add Row Level Security / backend authorization before production.
Admin operations must be checked server-side.
*/
