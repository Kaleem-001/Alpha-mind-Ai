# Production setup

1. Configure Firebase Auth or Supabase Auth.
2. Configure Google OAuth client and redirect/deep-link settings.
3. Configure email/password and phone OTP.
4. Add real backend URL.
5. Add AI provider credentials ONLY on backend.
6. Configure image generation provider.
7. Configure a real video provider.
8. Configure cloud image storage.
9. Configure database + RLS/authorization.
10. Create admin role server-side.
11. Configure Android signing SHA-1/SHA-256 for OAuth.
12. Test production APK, not only debug.
13. Test Hindi TTS engine installed on device.
14. Test microphone/camera/notification permissions.
15. Test network timeout, retry and quota errors.
16. Never display fake AI/image/video results.
