package ai.alphamind.app

enum class AiMode {
    GENERAL, TEACHER, CODING, CYBERSECURITY, VOICE_ASSISTANT
}

data class ChatMessage(
    val id: String,
    val role: String,
    val text: String,
    val timestamp: Long,
    val mode: AiMode
)

data class UserSettings(
    val language: String = "auto",
    val voiceEnabled: Boolean = true,
    val voiceLanguage: String = "hi-IN",
    val theme: String = "system",
    val speechSpeed: Float = 1.0f
)
