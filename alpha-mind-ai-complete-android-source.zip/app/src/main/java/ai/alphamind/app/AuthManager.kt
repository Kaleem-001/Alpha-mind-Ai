package ai.alphamind.app

/**
 * Production auth contract.
 * Implement with Firebase Auth or Supabase Auth:
 * - Google OAuth
 * - Email/password
 * - Phone/OTP
 * - Logout
 * - Secure session refresh
 *
 * Never collect a Google password inside this app.
 */
class AuthManager {
    fun signInWithGoogle() { /* configure provider credentials */ }
    fun signInWithEmail(email: String, password: String) {}
    fun signInWithPhoneOtp(phone: String, otp: String) {}
    fun signOut() {}
}
