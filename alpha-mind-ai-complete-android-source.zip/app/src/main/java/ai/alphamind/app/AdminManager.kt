package ai.alphamind.app

/**
 * Admin UI contract.
 * Real authorization MUST be enforced by the backend/database, not only by this APK.
 */
data class AdminUser(
    val id: String,
    val email: String,
    val role: String,
    val active: Boolean,
    val usage: Long
)

class AdminManager {
    fun isAdmin(userId: String): Boolean = false
    fun listUsers(): List<AdminUser> = emptyList()
    fun setUserActive(userId: String, active: Boolean) {}
    fun getServerStatus(): String = "unknown"
    fun getUsageStats(): Map<String, Long> = emptyMap()
}
