package ai.alphamind.app

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.provider.Settings
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.widget.Toast

class AssistantCommandRouter(private val context: Context) {
    fun execute(command: String) {
        val c = command.lowercase()
        when {
            "torch on" in c || "flashlight on" in c || "टॉर्च ऑन" in c ->
                setTorch(true)
            "torch off" in c || "flashlight off" in c || "टॉर्च ऑफ" in c ->
                setTorch(false)
            "camera" in c || "कैमरा" in c ->
                context.startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
            "youtube" in c || "यूट्यूब" in c ->
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
            "settings" in c || "सेटिंग" in c ->
                context.startActivity(Intent(Settings.ACTION_SETTINGS))
            "volume up" in c || "आवाज़ बढ़ाओ" in c ->
                volume(AudioManager.ADJUST_RAISE)
            "volume down" in c || "आवाज़ कम करो" in c ->
                volume(AudioManager.ADJUST_LOWER)
            else -> Toast.makeText(context, "Command AI/backend ko bhejo: $command", Toast.LENGTH_SHORT).show()
        }
    }

    private fun volume(direction: Int) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustVolume(direction, AudioManager.FLAG_SHOW_UI)
    }

    private fun setTorch(on: Boolean) {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull() ?: return
        cm.setTorchMode(id, on)
    }
}
