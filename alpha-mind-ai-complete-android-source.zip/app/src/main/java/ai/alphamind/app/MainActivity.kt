package ai.alphamind.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var voice: VoiceAssistant
    private lateinit var router: AssistantCommandRouter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        voice = VoiceAssistant(this)
        router = AssistantCommandRouter(this)

        // UI actions should call:
        // voice.startListening()
        // voice.speakHindi(text)
        // router.execute(command)
        // AuthManager for login/session
        // AdminManager for admin-only screens
    }
}
